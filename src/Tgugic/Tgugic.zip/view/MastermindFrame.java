package Tgugic.view;

import Tgugic.model.MastermindState;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class MastermindFrame extends JFrame implements MastermindGUI {
    private MastermindLayout layout;

    public MastermindFrame(ActionListener controller) {
        setTitle("Mastermind");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        layout = new MastermindLayout();
        layout.btnCheck.addActionListener(controller);
        layout.btnNeu.addActionListener(controller);
        layout.btnLoesung.addActionListener(controller);

        add(layout);
        this.setMinimumSize(new Dimension(500, 350));
        setSize(500, 350);
        setVisible(true);
    }

    public void startGame() {
        layout.setStatus("Neues Spiel gestartet.");
        for (FormPanel fp : layout.formPanels) fp.clear();
    }

    public void setState(MastermindState state) {
        if(state.won) {
            layout.setStatus("Gewonnen! Runde " + state.round);
        } else {
            layout.setStatus("Runde " + state.round + ": " + state.correctplace + " richtige Positionen.");
        }

        for (FormPanel fp : layout.formPanels) fp.clear();

        int[] forms = {
                FormPanel.CIRCLE,
                FormPanel.SQUARE,
                FormPanel.TRIANGLE,
                FormPanel.CIRCLE,
                FormPanel.SQUARE
        };

        for (int i = 0; i < state.correctplace; i++) {
            layout.formPanels[i].setForm(forms[i]);
            layout.formPanels[i].setColor(Color.GREEN);
            layout.formPanels[i].setFilled(true);
            layout.formPanels[i].draw();
        }

        for (int i = 0; i < state.correctnumber; i++) {
            layout.formPanels[i + 5].setForm(forms[i]);
            layout.formPanels[i + 5].setColor(Color.ORANGE);
            layout.formPanels[i + 5].setFilled(false);
            layout.formPanels[i + 5].draw();
        }
    }

    public void showSolution(int[] numbers) {
        String sol = "";
        for (int n : numbers) sol += n + " ";
        JOptionPane.showMessageDialog(this, "Die Lösung war: " + sol);
        layout.setStatus("Spiel beendet.");
    }

    public int[] getNumbers() {
        int[] nums = new int[5];
        for(int i = 0; i < 5; i++) {
            String text = layout.textFields[i].getText();
            if (text.trim().isEmpty()) {
                showError("Bitte alle 5 Felder ausfüllen!");
                return null; // Wenn ein Feld leer ist,  "nichts" zurück
            }
            try {
                nums[i] = Integer.parseInt(text);
            } catch (Exception e) {
                showError("Bitte nur Zahlen eingeben!");
                return null; // Wenn keine Zahl eingegeben wurde
            }
        }
        return nums;
    }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
}