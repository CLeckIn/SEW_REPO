package Tgugic.view;

import javax.swing.*;
import java.awt.*;

public class MastermindLayout extends JPanel {
    public FormPanel[] formPanels = new FormPanel[10];
    public JTextField[] textFields = new JTextField[5];
    public JButton btnCheck, btnNeu, btnLoesung;
    private JLabel statusLabel;

    public MastermindLayout() {
        setLayout(new BorderLayout(0, 0));

        JPanel northPanel = new JPanel(new BorderLayout(5, 5));

        JPanel inputPanel = new JPanel(new GridLayout(1, 5, 5, 5));
        for (int i = 0; i < 5; i++) {
            textFields[i] = new JTextField();
            textFields[i].setFont(new Font("Arial", Font.PLAIN, 20));
            textFields[i].setHorizontalAlignment(JTextField.CENTER);
            inputPanel.add(textFields[i]);
        }
        northPanel.add(inputPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(3, 1 , 2, 2));
        btnCheck = new JButton("Check");
        btnNeu = new JButton("Neu");
        btnLoesung = new JButton("Lösung");

        btnCheck.setActionCommand("CHECK");
        btnNeu.setActionCommand("NEU");
        btnLoesung.setActionCommand("LÖSUNG");

        buttonPanel.add(btnCheck);
        buttonPanel.add(btnNeu);
        buttonPanel.add(btnLoesung);
        northPanel.add(buttonPanel, BorderLayout.EAST);
        add(northPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(2, 5, 5, 5));
        for (int i = 0; i < 10; i++) {
            formPanels[i] = new FormPanel(-1, Color.BLACK, true);
            centerPanel.add(formPanels[i]);
        }
        add(centerPanel, BorderLayout.CENTER);

        statusLabel = new JLabel("Willkommen!", SwingConstants.CENTER);
        add(statusLabel, BorderLayout.SOUTH);
    }

    public void setStatus(String text) { statusLabel.setText(text); }
}