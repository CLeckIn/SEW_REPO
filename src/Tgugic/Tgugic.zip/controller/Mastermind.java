package Tgugic.controller;

import Tgugic.model.*;
import Tgugic.view.*;
import java.awt.event.*;

public class Mastermind implements ActionListener {
    private MastermindGUI view;
    private MastermindLogic model;

    public Mastermind() {
        this.model = new MastermindLogic();
        this.view = new MastermindFrame(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        if ("NEU".equals(cmd)) {
            model.newGame();
            view.startGame();

        } else if ("CHECK".equals(cmd)) {
            // 1. Zuerst prüfen, ob das Spiel überhaupt läuft
            if (model.getRoundCount() == 0) {
                view.showError("Starten Sie zuerst ein neues Spiel!");
                return;
            }

            int[] numbers = view.getNumbers();

            // 3. Nur wenn wir Zahlen bekommen haben, rechnen wir
            if (numbers != null) {
                try {
                    MastermindState state = model.calculateState(numbers);
                    view.setState(state);
                } catch (NoGameException ex) {
                    view.showError(ex.getMessage());
                }
            }

        } else if ("LÖSUNG".equals(cmd)) {
            try {
                view.showSolution(model.getSolution());
            } catch (NoGameException ex) {
                view.showError(ex.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        new Mastermind();
    }
}